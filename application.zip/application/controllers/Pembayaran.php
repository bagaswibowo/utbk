<?php

class Pembayaran extends CI_Controller{
    public function index()
    {
        $this->load->view('pembayaran/index');
    }
}